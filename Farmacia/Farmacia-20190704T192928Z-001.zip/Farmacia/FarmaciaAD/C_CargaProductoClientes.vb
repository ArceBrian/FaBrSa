﻿
Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Practices.EnterpriseLibrary.Data

Public Class C_CargaProductoClientes
    Dim oDatabase As Database

    Public Sub New()
        oDatabase = DatabaseFactory.CreateDatabase("Conn")
    End Sub

#Region "BuscarPorID"
    Public Function BuscarPorId(ByVal IdProducto As Integer) As DataSet
        Return oDatabase.ExecuteDataSet("ProductosBuscarPorId", IdProducto)
    End Function
#End Region

#Region "BuscarPorTroquel"
    Public Function BuscarPorNombre(ByVal txtProducto As String) As DataSet
        Return oDatabase.ExecuteDataSet("ProductosBuscarPorTroquel", txtProducto)
    End Function
#End Region

#Region "AGG Productos"
    Public Function Agregar(ByVal NombreCliente As String, ByVal Producto As String, ByVal Cantidad As Integer, ByVal Fecha As Date) As Double
        Return oDatabase.ExecuteScalar("ProductosAgregar", NombreCliente, Producto, Cantidad, Fecha)
    End Function
#End Region

#Region "Modifiacar"
    Public Function Modificar(ByVal IdCliente As Integer, ByVal NombreCliente As String, ByVal Descripcion As String, ByVal Cantidad As Integer, ByVal Fecha As Date) As Double
        Return oDatabase.ExecuteScalar("CompraClienteModificar", IdCliente, NombreCliente, Descripcion, Cantidad, Fecha)
    End Function
#End Region

#Region "BuscarTodos"
    Public Function BuscarTodos() As DataSet
        Return oDatabase.ExecuteDataSet("CuentaBuscarTodos")
    End Function
#End Region

End Class
