﻿Imports FarmaciaAD
Public Class frm_CargaProductoClientes

    Private Sub frm_CargaProductClientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Estado = EstadodelFormulario.eConsulta
    End Sub

#Region "BuscarIdProducto"
    Private Sub cmdBuscarIdProducto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBuscarIdProducto.Click
        Dim ods As New DataSet
        Dim oFarmacia As New C_CargaProductoClientes

        If txtIdProducto.Text <> Nothing Then
            ods = oFarmacia.BuscarPorId(txtIdProducto.Text)

            If ods.Tables(0).Rows.Count > 0 Then
                txtTroquel.Text = (ods.Tables(0).Rows(0).Item("Descripcion"))
                txtProducto.Text = (ods.Tables(0).Rows(0).Item("PrecioVentaCliente"))
            End If
        Else
            MsgBox("Este ID es inexistente", vbInformation, "Cargar")
        End If
    End Sub
#End Region

#Region "BuscarNombreProducto"
    Private Sub cmdBuscarProducto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBuscarProducto.Click
        Dim ods As New DataSet
        Dim oFarmacia As New C_CargaProductoClientes

        If txtTroquel.Text <> Nothing Then
            ods = oFarmacia.BuscarPorNombre(txtTroquel.Text)

            If ods.Tables(0).Rows.Count > 0 Then
                txtIdProducto.Text = (ods.Tables(0).Rows(0).Item("IdProducto"))
                txtProducto.Text = (ods.Tables(0).Rows(0).Item("Descripcion"))
                txtPrecio.Text = (ods.Tables(0).Rows(0).Item("PrecioVentaCliente"))
            End If
        Else
            MsgBox("Este Nombre es inexistente", vbInformation, "Cargar")
        End If
    End Sub
#End Region


#Region "Variables"

    Private eEstado As EstadodelFormulario

#End Region

#Region "Enumeraciones"

    Public Enum EstadodelFormulario
        eConsulta = 1
        eAgregar = 2
        eEditar = 3
    End Enum

#End Region

#Region "Propiedades"

    Public Property Estado() As EstadodelFormulario
        Get
            Return eEstado
        End Get
        Set(ByVal vNewValue As EstadodelFormulario)


            Select Case vNewValue

                Case EstadodelFormulario.eConsulta

                    Limpiar()
                    DesHabililarEdicion()
                    DesHabililarComandos()
                    CmdAgregar.Enabled = True
                    CmdAceptar.Enabled = False
                    CmdCancelar.Enabled = False
                    grlGrillaa.Enabled = True
                    Panel1.BackColor = Color.White
                    LblAccion.Text = "Consultando"
                    LblAccion.ForeColor = Color.Black

                Case EstadodelFormulario.eAgregar

                    HabililarEdicion()
                    txtIdCliente.Enabled = False
                    CmdAceptar.Enabled = True
                    CmdCancelar.Enabled = True
                    DesHabililarComandos()
                    grlGrillaa.Enabled = False
                    Limpiar()
                    txtProdClien.Focus()
                    txtCantidad.Focus()
                    txtFecha.Focus()
                    Panel1.BackColor = Color.GreenYellow
                    LblAccion.Text = "Agregando"
                    lblAccion.ForeColor = Color.Black

                Case EstadodelFormulario.eEditar

                    HabililarEdicion()
                    txtIdCliente.Enabled = False
                    CmdAceptar.Enabled = True
                    CmdCancelar.Enabled = True
                    DesHabililarComandos()
                    grlGrillaa.Enabled = False
                    Panel1.BackColor = Color.GreenYellow
                    LblAccion.Text = "Modificando"
                    lblAccion.ForeColor = Color.Black

            End Select
            eEstado = vNewValue
        End Set
    End Property

#End Region

#Region "Formulario"

    'Private Sub FrmRubros_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    '    Me.Estado = EstadodelFormulario.eConsulta

    'End Sub



    Private Sub FrmRoles_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)

        If e.KeyCode = Keys.F3 And cmdAgregar.Enabled = True Then ' agregar
            Me.Estado = EstadodelFormulario.eAgregar
        End If

        If e.KeyCode = Keys.F4 And cmdModificar.Enabled = True Then ' modificar
            Me.Estado = EstadodelFormulario.eEditar
        End If


        If e.KeyCode = Keys.F12 And cmdLimpiar.Enabled = True Then ' limpiar
            Me.Estado = EstadodelFormulario.eConsulta
        End If


    End Sub

    Private Sub FrmRoles_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)

        If Asc(e.KeyChar) = Keys.Escape Then
            Me.Dispose()
        End If

    End Sub


#End Region

#Region "Procedimientos"

    Private Sub CargarGrilla()

        BuscarTodos()

    End Sub

    Private Sub CargarClientes()

        Dim oDs As New DataSet
        Dim oFarmacia As New C_CargaCliente

        oDs = oFarmacia.BuscarTodos

        cboClientes.DataSource = oDs.Tables(0)
        cboClientes.ValueMember = oDs.Tables(0).Columns(0).ToString
        cboClientes.DisplayMember = oDs.Tables(0).Columns(1).ToString

        oDs = Nothing
        oFarmacia = Nothing

    End Sub

    Private Sub BuscarTodos()


        Dim oDs As New DataSet
        Dim oFarmacia As New C_CargaProductoClientes

        oDs = oFarmacia.BuscarTodos

        grlGrillaa.DataSource = oDs.Tables(0)

        grlGrillaa.Columns(0).HeaderText = "Cod."
        grlGrillaa.Columns(0).Width = 50

        oDs = Nothing
        oFarmacia = Nothing

    End Sub

    Private Sub BuscarPorID(ByVal ID As Integer)


        Dim oDs As New DataSet
        Dim oFarmacia As New C_CargaProductoClientes

        oDs = oFarmacia.BuscarPorId(ID)

        txtIdCliente.Text = oDs.Tables(0).Rows(0).Item("IdCliente")
        cboClientes.SelectedValue = oDs.Tables(0).Rows(0).Item("NombreCliente")
        txtProducto.Text = oDs.Tables(0).Rows(0).Item("Producto")
        txtCantidad.Text = oDs.Tables(0).Rows(0).Item("Cantidad")
        txtFecha.Text = oDs.Tables(0).Rows(0).Item("Fecha")

        oDs = Nothing
        oFarmacia = Nothing

    End Sub

    Private Sub Limpiar()

        CargarGrilla()
        txtIdCliente.Text = ""
        txtIdProducto.Text = ""
        txtPrecio.Text = ""
        txtProducto.Text = ""
        txtProdClien.Text = ""
        txtCantidad.Text = ""
        txtFecha.Text = ""
        txtTroquel.Text = ""
        CargarClientes()

    End Sub

    Private Sub HabililarEdicion()

        txtIdCliente.Enabled = True
        cboClientes.Enabled = True
        txtProdClien.Enabled = True
        txtCantidad.Enabled = True
        txtFecha.Enabled = True

    End Sub

    Private Sub DesHabililarEdicion()

        txtIdCliente.Enabled = False
        cboClientes.Enabled = False
        txtProdClien.Enabled = False
        txtCantidad.Enabled = False
        txtFecha.Enabled = False

    End Sub

    Private Sub HabililarComandos()

        CmdAgregar.Enabled = True
        CmdModificar.Enabled = True


    End Sub

    Private Sub DesHabililarComandos()

        CmdAgregar.Enabled = False
        CmdModificar.Enabled = False


    End Sub

#End Region

#Region "Botones de Comando"

    Private Sub CmdLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLimpiar.Click
        Me.Estado = EstadodelFormulario.eConsulta
    End Sub

    Private Sub CmdModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdModificar.Click
        Me.Estado = EstadodelFormulario.eEditar
    End Sub

    Private Sub CmdAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Try

            If Validar() = True Then


                Dim oFarmacia As New C_CargaProductoClientes


                If Me.Estado = EstadodelFormulario.eEditar Then
                    oFarmacia.Modificar(txtIdCliente.Text, cboClientes.SelectedValue, txtProdClien.Text, txtCantidad.Text, txtFecha.Text)
                    MsgBox("Se modificó correctamente el cliente el código Nro: " + txtIdCliente.Text, MsgBoxStyle.Information, "Exitos!")
                End If

                If Me.Estado = EstadodelFormulario.eAgregar Then
                    Dim resultado As Integer
                    resultado = oFarmacia.Agregar(cboClientes.SelectedValue, txtProdClien.Text, txtCantidad.Text, txtFecha.Text)
                    MsgBox("Se agregó correctamente el cliente " + txtIdCliente.Text + " con el código Nro: " + resultado.ToString, MsgBoxStyle.Information, "Exitos!")
                End If

                Me.Estado = EstadodelFormulario.eConsulta

            End If

        Catch

            MsgBox("Sucedió un error", MsgBoxStyle.Critical, "Error")

        End Try


    End Sub

    Private Sub cmdCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancelar.Click
        If MsgBox("Esta seguro de Cancelar?" & vbCrLf & _
               "Se perderán las ultimas modificaciones", _
               vbYesNo, "Confirmacion de Accion") = MsgBoxResult.Yes Then

            Me.Estado = EstadodelFormulario.eConsulta

        End If

        Exit Sub
    End Sub

    Private Sub CmdAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAgregar.Click
        Me.Estado = EstadodelFormulario.eAgregar
    End Sub

#End Region

#Region "Grilla"
    Private Sub grl_Grilla_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

        BuscarPorID(grlGrillaa.CurrentRow.Cells(0).Value)
        cmdModificar.Enabled = True

    End Sub
#End Region

    '#Region "Grilla"

    '    Private Sub Grilla_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellErrorTextNeededEventArgs) Handles grlGrillaa.CellDoubleClick

    '        BuscarPorID(grlGrillaa.CurrentRow.Cells(0).Value)
    '        cmdModificar.Enabled = True

    '    End Sub

    '#End Region

#Region "Funciones"

    Private Function Validar() As Boolean

        If txtProdClien.Text = "" Then

            MsgBox("Complete el nombre del producto", MsgBoxStyle.Exclamation, "Mensaje")
            Return False

        End If


        Return True

    End Function

#End Region

#Region "Salir"
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub
#End Region

#Region "Solo N° o letras"
    Private Sub txtIdProducto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtIdProducto.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtIdCliente_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtIdCliente.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtPrecio_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtProducto.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCantidad_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCantidad.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtTroquel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTroquel.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
#End Region

End Class